using System;
using System.Windows.Forms;

namespace Yusen.GExplorer {
	partial class UserSettingsToolbox : Form, IUsesUserSettings{
		private static UserSettingsToolbox instance = null;
		public static UserSettingsToolbox Instance {
			get {
				if(null == UserSettingsToolbox.instance || !UserSettingsToolbox.instance.CanFocus) {
					UserSettingsToolbox.instance = new UserSettingsToolbox();
				}
				return UserSettingsToolbox.instance;
			}
		}
		
		private UserSettingsToolbox() {
			InitializeComponent();
			this.LoadSettings();
			this.Icon = Utility.GetGExplorerIcon();
			this.Text = "���[�U�ݒ�c�[���{�b�N�X";
			
			this.propertyGrid1.SelectedObject = UserSettings.Instance;
			
			//��Ɏ�O�ɕ\��
			this.chkTopMost.CheckedChanged += new EventHandler(delegate(object sender, EventArgs e) {
				this.TopMost = this.chkTopMost.Checked;
				this.SaveSettings();
			});
			
			//���[�U�ݒ�
			this.LocationChanged += delegate {
				this.SaveSettings();
			};
			this.SizeChanged += delegate {
				this.SaveSettings();
			};
			this.propertyGrid1.PropertyValueChanged += new PropertyValueChangedEventHandler(
				delegate(object s, PropertyValueChangedEventArgs e) {
					UserSettings.Instance.OnChangeCompleted(true);
				});
			UserSettings.Instance.ChangeCompleted +=
				new UserSettingsChangeCompletedEventHandler(this.ListeningUserSettings);
			this.FormClosing += new FormClosingEventHandler(
				delegate(object sender, FormClosingEventArgs e) {
					if(FormWindowState.Minimized == this.WindowState) {
						//�ŏ��������܂܏I�������ƃE�B���h�E�ʒu���ςɂȂ�̂Ō��ɖ߂�
						this.WindowState = FormWindowState.Normal;
					}
					UserSettings.Instance.ChangeCompleted -= this.ListeningUserSettings;
				});
		}
		
		private void ListeningUserSettings() {
			this.LoadSettings();
			this.propertyGrid1.Refresh();
		}
		public void LoadSettings(){
			UserSettings.Instance.UserSettingsToolbox.ApplySettings(this);
			this.chkTopMost.Checked = this.TopMost;
		}
		public void SaveSettings() {
			UserSettings.Instance.UserSettingsToolbox.StoreSettings(this);
			UserSettings.Instance.UserSettingsToolbox.OnChangeCompleted();
		}
	}
}
